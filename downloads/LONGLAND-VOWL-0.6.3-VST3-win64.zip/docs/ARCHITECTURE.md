# Architecture

The processor owns parameter/state, routing and output safety. Cached parameter atomics are read at block boundaries. DSP classes own prepared fixed-size state and expose prepare/reset/process without GUI or ValueTree access. Editors use JUCE attachments. Audio-to-GUI meters are relaxed atomics.

Main input is the modulator. Optional matching mono/stereo sidechain is the external carrier. Main output matches the modulator. Synthesized speech can operate with silent modulator input. Bypass continues internal state while smoothly returning to dry input.

The first engine is a variable-resolution filterbank. Band envelopes form a bounded SpectralFrame for later memory and transformation modules. Fundamentally different analysis algorithms will have their own implementation rather than disguised presets.

Filterbank: constant-peak biquads ([RBJ / W3C](https://www.w3.org/TR/audio-eq-cookbook/)), rectified attack/release envelopes, matching synthesis filters. Two preallocated banks crossfade over 12 ms on topology changes. High-frequency energy controls noise excitation, with a separate consonant-detail path. The latter intentionally passes some high-passed modulator signal. Oscillators use polynomial BLEP at discontinuities; triangle integrates the corrected square. No lookahead: reported latency is zero. Output has a hard safety ceiling; gain should be set to avoid hitting it in normal use.

Phoneme definitions, key mappings and synthesis are separate layers. `BankState` serializes GUI/state writers under a non-audio mutex and publishes fixed POD snapshots through a single-consumer triple buffer. The audio callback only exchanges an atomic slot index. Voices copy their speech definitions at note onset. UI MIDI uses a bounded SPSC queue. State and user presets include both elements of each syllable, all 128 mappings and the selected editor key.

The Voder uses ten fixed channels with buzz/noise and manual gains or a tract-to-channel mapping. The formant model uses five independent resonators with smoothly moving frequencies, bandwidths, gains and excitation mixtures; a shaped noise path, nasal pole and timed closure/burst are separate. These are original musical approximations, not linguistic accuracy claims. Background: [Julius O. Smith, Formant Synthesis Models](https://dsprelated.com/freebooks/pasp/Formant_Synthesis_Models.html).


## 0.2 routing and recording

The vocoder's modulator selector crossfades among main audio, Voice Synth, Voder and Phonic Keys. The internal sources are generated before vocoding. Source weights normalize during interrupted transitions. Carrier keyboard/fixed pitch is explicit; noise and external carriers retain their natural behavior. Existing parameter IDs and choice indices remain intact; new controls use new IDs, and old state supplies their defaults. Selected-sound pitch uses an internal fourth Phonic routing mode without renumbering the published three-choice MIDI mode.

Incoming MIDI remains in the host buffer. GUI packets are consumed only when the output can fit JUCE 9's guaranteed 2048-byte VST3 callback reserve (other direct processor callers must reserve it too); excess GUI packets stay queued. Flood counting stops at 2049 events. Queue/input overflow resets voices and emits bounded all-sound-off output; state restoration uses a separate reset path that preserves the first incoming note. No callback MIDI storage allocation is required by the plugin. The VST3 wrapper and host remain outside that callback storage guarantee.

The internal capture backend remains regression-tested but is no longer exposed in the editor as of 0.6.2. It sends timestamped channel events and tempo changes over a fixed SPSC FIFO to the message thread. Generation tags isolate retakes, including delayed old events. The message thread owns a bounded take and writes MIDI files. Overflow uses a generation-matched stop; file I/O never runs in processBlock. Capture is not part of project/preset state.

The assignment piano operates on BankState off the audio thread. Factory sound selection stages a sound; picking a target publishes it immediately. Edit-existing loads without changing a mapping. Linear fill publishes the entire contiguous sequence once; the upper MIDI boundary clips the fill.
