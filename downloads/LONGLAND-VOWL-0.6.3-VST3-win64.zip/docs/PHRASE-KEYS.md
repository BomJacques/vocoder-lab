# Phrase keys and phoneme sequencing

Open **Phonic Keys → Words to keys**. Select a target note on the labeled mapping piano, type English words, then click **Assign words**. Incoming MIDI or the bottom performance piano now triggers that phrase on its assigned key. Preview plays it once; Stop releases the phrase. Unassigned keys keep their ordinary phoneme sounds. Entering Phonic Keys still opens the rounded sound tiles, and clicking a sound tile replaces a phrase on that key immediately.

The sequence strip shows eight steps at a time; use the arrows for later steps. Select a step and edit its sound, duration and pitch offset. **Rest** inserts silence between sounds; **Add rest** appends a step and **Remove** deletes the selected step. Changes save to the selected key immediately. Assign words regenerates the whole sequence from the text and replaces manual step edits. Unbuilt text is retained separately from the last built phrase name and carries a warning until rebuilt.

Playback modes:

- **One-shot:** finish the phrase after releasing the key. Another mapped note restarts the phrase lane with its own sequence.
- **Hold:** play once; releasing the owning key releases the voice early.
- **Loop:** repeat until the owning key is released. The sustain pedal can hold Hold/Loop phrases; releasing it, resetting controllers or sending all-notes-off ends them.

There is **one phrase lane**. The latest mapped note wins; releasing an older note or another channel does not stop the current phrase. Ordinary unmapped phoneme voices remain polyphonic. MIDI velocity controls phrase level, and pitch bend follows the owning channel with a two-semitone range. **Note pitch** uses the trigger note's pitch; turn it off to use Voice pitch Hz from Speech Synth. The singing matrix and engine-character settings apply to mapped phrases. Individual engines retain their documented pitch limits.

**Tempo sync** fits the entire sequence into the chosen 1–32 quarter-note beats. Step durations become relative weights. Playback starts at the incoming MIDI timestamp, follows host tempo changes, and is not quantized to the song grid. The fallback tempo without host information is 120 BPM. Without sync, durations are milliseconds divided by the existing Speech rate setting (2x plays twice as fast). Tempo-synced playback uses beats instead of Speech rate. Host transport stopping releases the phrase; keys can also be auditioned while transport is stopped. Releasing a phrase leaves its short natural audio tail.

Limits: all 128 MIDI notes may hold phrases; each assigned phrase has up to 128 steps and 256 input characters (the text compiler accepts up to 256 ASCII bytes). Each step is 10–2000 ms with a -24 to +24 semitone offset. The original Speak button in Speech Synth retains its separate 512-step capacity. Long mapped text is explicitly marked when truncated; shorten it to retain all words. Build operations and pronunciation lookup run outside the audio callback. Playback owns a copy of its sequence, so editing a playing phrase takes effect on the next trigger.

The reported host tail remains 20 seconds for ordinary maps and expands when a configured phrase can last longer at the slowest supported rate/tempo. A playing copy retains its bound after live map edits. This is a conservative rendering allowance, not added audio latency.

Projects and `.vlab` presets store phrase assignments, edited steps, playback/timing options and text drafts. Restoring state stops playback and discards stale queued GUI notes; it never autoplays. Legacy presets have empty phrase maps. Clear key disables both the phrase and its ordinary sound; assigning a tile or using linear fill replaces phrases in the affected key range. Saving a custom vowel to a key also replaces its phrase.

Four factory presets map **C3, D3, E3 and F3 (MIDI 48, 50, 52, 53)**:

- **PHRASE / TI welcome:** one-shot greeting phrases at a fixed voice pitch.
- **PHRASE / Klatt announcement:** one-shot announcement phrases.
- **PHRASE / FOF sung words:** note-pitched, four-beat phrases with longer vowels and an edited pitch contour.
- **PHRASE / FS rhythm loop:** note-pitched two-beat loops while held.

All ten speech backends work with phrase keys. For audio vocoding, use **Vocoder → Phonic Keys** as the speech source; mapped MIDI notes also play the carrier. Phrase steps produce audio, not generated MIDI notes. The original incoming trigger notes retain their timing in MIDI output/capture. Record trigger notes in Reason's sequencer using its Computer Keys or a MIDI keyboard. The plugin piano auditions sounds. These are authored musical speech sequences, not original hardware word ROMs or a lyric-alignment system.

In 0.6.1, choose Advanced in the header to edit individual sequence steps. Easy keeps word assignment and playback settings visible. See [GUI-GUIDE.md](GUI-GUIDE.md).
