## 0.6.3 UI update

Products renamed longland VOWL and longland VOWL Instrument. Record/Save MIDI buttons removed; Help directs recording to the host. The Blender faceplate is a separate design asset. Debug 14/14 (47.44 s) and Release 14/14 (6.53 s) pass.

# Status

WORKING
- 0.6.1 adds Easy/Advanced views, persistent Sound tiles/Words to keys routes, visible Vowel touch pad, explicit save target, typed-word draft transfer, hover help and a built-in guide. No DSP or parameter identity changes.
- 0.6 adds MIDI phrase assignments, an editable sound/duration/pitch sequence, one-shot/hold/loop playback, owner-channel sustain and pitch bend, tempo-relative timing, independent drafts and saved phrase banks. All ten engines use the same phrase lane. Four phrase presets are included. See PHRASE-KEYS.md.
- 0.5.2 restores the rounded phonetic tiles on entry to Phonic Keys, clearing previous-tab detail/engine/singing views. Edit sound / Sound tiles makes the alternate view explicit. Select a mapping note, then click a grouped tile to assign immediately.
- 0.5.1 fixes clicks on speech-engine note runs: connected closure timing, bounded 3 ms output transitions, preserved SP impulse/MEA interpolation continuity, and responsive release-tail retriggers. Core reference synthesis remains unchanged.
- Version 0.6.0: effect and instrument VST3 products; fourteen CTest suites in Debug and Release, including actual DLL discovery/processing for both products.
- Version 0.6.1: both products compile; Debug 14/14 and Release 14/14 pass, with the new GUI navigation/state/assignment regressions and inspected live-component renders. See GUI-GUIDE.md and VALIDATION.md. Reason workflow retest remains pending.
- Classic filterbank with 8/10/16/20/32/64 bands; eleven carrier choices including external audio; consonant paths; stereo envelopes; topology/carrier crossfades; smoothed bypass/mix/gain; metering.
- Manual/articulated Voder; programmable five-formant voice, four excitation types, nasal/noise/closure/burst/envelopes; vowel XY designer and save to key.
- 48 factory speech sounds, all 128 editable mappings, two-element syllables, fixed/split/pitched MIDI modes, 1–8 voices, stealing, sustain, bend/pressure/mod-wheel expression and articulation interpolation.
- Charcoal/amber resizable GUI, retro TI speech panel, editable programmer, 42 factory presets and complete custom-map user preset/state serialization.
- TI 5100 synthesis core with original lookup tables, serial frame decoding, integer lattice/interpolation/noise behavior, authored phoneme conversion, musical/chip-table pitch modes and up to eight voices. See TI-SPEECH.md for exact scope and reference tests.

- 0.5 adds MEA8000, FOF, Digitalker, FS-inspired 8+8 and Klatt as separate speech backends, plus a live LPC-10 output codec. Engine controls, legacy automation mapping and new presets are integrated. Original ROM/full device/FS1R firmware/DECtalk equivalence is not claimed.

- 0.4 adds SP0256 integer synthesis, SC-01A circuit synthesis, SID digital saw/pulse/triangle and AY tone/noise carriers; a singing matrix; grouped immediate-assignment tiles; and offline English typed phrases on all speech backends. See RETRO-ENGINES.md and TEXT-SPEECH.md for limitations. No original SP/SC phone ROMs or complete SID/AY device emulation are included.

- 0.2 update: selected-sound keyboard pitch, internal Voice Synth/Voder/Phonic-to-vocoder routing, shared performance piano, MIDI through/output, built-in MIDI capture/export, automatic labeled-piano assignments, and linear vowel/full-phonics fill.
- Reason-specific usage is documented in README. Reason's own VST MIDI-output restriction remains; use its sequencer with incoming keyboard notes. The capture backend remains tested internally but is no longer exposed in the editor.

PARTIAL
- Full gauntlet roadmap; this release completes the selected six-engine expansion for its documented synthesis scope.
- The original Formant engine uses a parallel nasal resonance and oral attenuation. Klatt adds a nasal pole/zero tract.
- Basic envelope display; dedicated formant/spectral-history visualizations are future work.

NOT IMPLEMENTED
- TI-compatible live LPC analysis, FFT/phase/cepstral vocoders, DECtalk/Perfect Paul, complete SID analogue profiles, spectral memory/shear/physics/matrix/multicarrier, song-position-locked sequencing, MPE.

KNOWN ISSUES
- Only VS2026 is installed; VS2022 build cannot be verified here.
- Standalone excluded by updated user instruction.
- User reports no more clicks after the 0.5.1/0.5.2 fixes. This confirms that reported playback symptom; broader pluginval/full-DAW validation and subjective voice-fidelity evaluation remain unverified. The new 0.6 phrase workflow still needs user testing in Reason. See VALIDATION.md.
- TI synthesis does not include the original vocabulary ROM, toy CPU, original text/word firmware, analogue speaker model or live LPC analysis. Tested reference agreement is not a claim of exhaustive hardware equivalence.
- The host tail has a 20-second baseline and expands for configured or playing long phrases; this is not added latency.

DELIVERY
- Source/CMake/VS presets: this project folder; Release VST3 bundles: `Binaries/Release/longland VOWL.vst3` and `Binaries/Release/longland VOWL Instrument.vst3`.
- Factory data: `Factory/` (42 presets and XML phoneme bank). Tests: `Tests/`.
- Spectral implementation: bounded envelope frames and live display only; no spectral-memory/physics claims.
- See VALIDATION.md for current regression results and independently checked synthesis sections.
- Next priorities: user testing of phrase performance in Reason, then live LPC analysis/resynthesis and FFT envelope transfer. Further historical-device fidelity and voice tuning remain on the roadmap. Blender remains paused. See ../../VocoderLab-Plan.md.
