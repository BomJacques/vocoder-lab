# Audit gates

Architecture gate: independent read-only review found four concrete issues. Primary implementation fixes: host reset clears DSP/MIDI/meters; filterbank reset rebuilds the requested topology; zero-length and boundary callbacks consume MIDI; carrier note state uses channel+key identity with sustain and channel-specific reset. Focused regressions cover each. VST3-only scope confirmed. No broad architectural redesign requested.

DSP/real-time gate: no callback heap allocation, blocking lock or triple-buffer race found in the reviewed call graph. Fixed single-read mode snapshots, channel-specific CC120, second-element pitch behavior and tail reporting. Formant release now reaches its cutoff within the programmed release time; a conservative 20-second host tail covers the maximum filterbank envelope. Excitation mixes interpolate and syllable sustain changes no longer jump the envelope.

Speech/MIDI gate: fixed GUI queue overflow ordering so panic discards pending note-ons, added articulation-specific burst/closure and attack rearming for split plosives and syllable tails, and restored last-held-note continuity when polyphony is reduced to mono. Targeted regressions added.

Final gate: independent clean Debug and Release VST3 builds and all four suites passed. Review found a Voice Synth expression identity bug; pressure now matches channel, poly pressure also matches note, and CC121 clears expression. New deterministic audio comparisons pass. Independent rerun on corrected source passed 4/4 in both configurations without compiler warnings. Audit closed with no outstanding confirmed defects. VS2022, pluginval, full DAW use and listening remain verification gaps, not claimed passes.


0.2 MIDI/routing audits: fixed state-recall panic discarding first host note, generation-specific recorder overflow, bounded flood detection, upper-register formant pitch clipping and interrupted source-crossfade weight sums. GUI note output is bounded by the actual JUCE VST3 reserve; Debug CRT hooks extend allocation checks to realloc. Auditors reviewed code without editing it.

Final assignment audit: cleared stale factory selections after loading/editing existing mappings, reset pending target selection so re-selecting the current note assigns correctly, and documented Reason multi-channel import behavior. Corrected paths rechecked with no outstanding actionable findings.
