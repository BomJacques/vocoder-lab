# TI speech engine

The **TI 5100** engine emulates the synthesis section of the early TMS5100 / TMC0281 A/B speech chip associated with Speak & Spell. It is implemented locally in C++ with fixed storage and no audio-thread allocation. It is available in both VST3 variants through **Speech engine** in Speech Synth, Phonic Keys, and Vocoder FX.

## Play

Load **VOCODER LAB INSTRUMENT** in Reason's Instruments browser. It starts in Speech Synth with **TI 5100 / keyboard** selected. Select a cream vowel button in the red speech-computer panel and play Reason's Computer Keys (F4), a MIDI controller, or the bottom piano. Reason's Master Keyboard Input must target the instrument track.

The FX product retains its existing **VOCODER LAB** name and plugin identity. For MIDI notes in that version, create a sequencer track for the effect and give it Master Keyboard Input. To vocode the TI voice, select **Voice Synth** as the vocoder speech source and **TI 5100 / keyboard** as the speech engine. The preset **TI / Speech into vocoder** sets this up.

**TI 5100 / keyboard** uses a musical pitch-period extension at the chip's fixed 8 kHz synthesis rate. It follows MIDI notes and pitch bend without changing the formant clock. **TI 5100 / chip pitch** quantizes the pitch to the original 31 nonzero pitch entries, approximately 52–195 Hz; adjacent keys can intentionally share a pitch. This setting is an original pitch-table option, not a full toy emulation mode.

The musical extension is limited to 8–3500 Hz. The on-screen TI piano ends at MIDI 104; higher incoming MIDI notes are clamped. One core runs per speech voice, up to eight. Phonic Keys retains fixed/split/pitched mapping, tails, channel identity, sustain, and bounded voice stealing. Switching speech engines resets held notes; release and play again after switching.

## What is emulated

- Original energy, pitch, reflection-coefficient and signed chirp lookup tables.
- MSB-first serial frame decoding: energy, repeat, pitch, four/ten coefficients, silence and stop.
- Ten-stage integer lattice filter, previous-sample energy pipeline, bounded arithmetic and speaker-output quantization.
- Voiced chirp and unvoiced noise; deterministic LFSR advanced 20 times per native sample.
- 200-sample frames, eight interpolation periods, per-parameter subcycle updates, interpolation inhibition and pitch-counter resets.
- Safe stop on a truncated serial stream. The DAW wrapper suppresses the hardware's idle DC value.

An independent pinned-MAME oracle supplies 2,048 primitive samples and 1,400 full-frame samples, including voiced/unvoiced, silence and stop transitions. These tests establish agreement with the selected reference cases, not exhaustive silicon or full-device equivalence. The frame fixture aligns startup with this core's immediate software API.

## Authored speech and musical extensions

No original vocabulary ROM, recordings or toy firmware is included. Version 0.4 adds a separate CMUdict-based typed-speech frontend; see TEXT-SPEECH.md. The existing authored phoneme definitions are converted to stable all-pole reflection coefficients and quantized to the chip's tables. This produces playable speech colours, not the original toy's recorded words. A 32-tap, 128-phase reconstruction filter resamples the 8 kHz core to the host rate. Its approximately 1.9 ms delay and the chip's frame onset are part of the voice articulation.

Voiced and unvoiced excitation are exclusive, as on the chip. Noise-dominant fricatives use unvoiced frames. Plosives use burst frequency, bandwidth, level and decay; B/P, D/T and G/K currently share burst shapes. The TI model does not separately reproduce breath, nasality, aspiration, pitch envelopes, or independent nonzero formant gain controls from the Formant engine. Formant frequencies/bandwidths and the voice envelope remain useful; frequencies above the native Nyquist range cannot be retained. **Sound details** exposes the shared programmer; choose **Formant** for its complete control set.

The emulation scope excludes CTL/PDC electrical timing, ROM addressing hardware, the toy CPU, SPKSLOW, later chip revisions, analogue electronics/speaker response, and live microphone LPC analysis. See [third-party notices](THIRD_PARTY_NOTICES.md) for the BSD reference attribution.

## Interface

The main shell uses the charcoal/amber rendered concept. The TI Speech Synth panel uses a red-orange enclosure, green display and cream phoneme keys. Mode tabs, a basic view, optional **Sound details**, input/output meters, and a persistent performance piano separate sound selection from key assignment. The red panel is an implemented JUCE interface; Blender work remains paused.
