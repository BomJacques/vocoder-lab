# Retro synthesis backends

These backends are separate implementations. Their authored phoneme banks and musical pitch controls are extensions; they do not contain original toy/computer speech ROMs. No blanket percentage of original-device fidelity is claimed. Core reference tests and voice-data authenticity are different checks.

## SP0256 / authored speech

The synthesis section implements six cascaded two-pole integer stages, asymmetric coefficient quantization, signed 16-bit stage wrapping, impulse/noise excitation, the 15-bit noise generator, excitation-boundary delay resets and amplitude/period interpolation registers. Sustained software register frames replace the AL2 ROM and microsequencer. There is no AL2 allophone ROM, serial instruction decoder or bus emulation.

An independent extraction of MAME's synthesis functions supplies 5,345 emitted samples covering twelve register scenarios. Tests compare the raw signed filter result and an explicitly defined signed 8-bit output quantizer. The pinned reference enables its higher-resolution output; its disabled low-resolution branch shifts an unsigned value before sign conversion, so this build does not reproduce that branch's negative-sample error. The quantizer is signed floor division by 16, saturation to -128â€¦127, then multiplication by 256.

The wrapper uses 3.12 MHz / 312 = 10 kHz, following upstream's divider correction in commit `638224548b67a2b8f4cbc561b38cfef211f122f6`. The older primitive fixture reference's divider of 336 is not used for playback. A voiced period is register value + 1 samples; keyboard pitches retain this integer resolution. Formants map to stable, quantized resonator coefficients with a sixth identity section. Host envelopes, amplitude expression and reconstruction filtering surround the native core.

## SC-01A / circuit voice

The analog synthesis path is adapted from the pinned MAME SC-01A circuit model: measured capacitor-ratio filters, glottal waveform, separate voiced/noise paths, F1/F2/F3/F4 sections, final low-pass and noise shaping. The model runs at 40 kHz, with a 20 kHz noise/control clock. The filter-control interpolators use the reference integer recurrence.

Authored formant frequencies select nearby capacitor-control codes; F2 bandwidth selects its Q code. MIDI pitch uses a musical phase extension. Host attack, sustain, release and burst envelopes replace the original phone-duration/controller machinery. No original SC-01A phone ROM, four-step inflection input model or complete digital controller is included.

The reference neutralizes an unstable F2 noise-injection branch and uses an empirical 150/4000 correction in the final low-pass. This build retains those limitations; noise still enters the later mixed path. Filter-control commits happen on the 20 kHz control tick instead of the original pitch-synchronized commit points, as part of the controller extension. It is a circuit-reference model, not a claim of complete analog silicon equivalence. F1/F3 bandwidth, F4/F5 programming, independent formant gains, nasality, breath and pitch-envelope controls from the generic Formant engine do not apply here.

## SID and Amstrad carrier sections

The carrier menu adds SID digital saw, pulse and triangle generators, plus Amstrad CPC AY-3-8912 tone and noise. They have distinct register-clock implementations rather than reusing the existing floating-point oscillators. The SID section uses a 24-bit phase accumulator, 16-bit frequency register and 12-bit waveform output at a 985,248 Hz clock. The AY section uses the CPC's 1 MHz clock, 12-bit tone divider and 17-bit noise generator. Native clock samples are averaged into host samples.

These are oscillator/carrier sections, not complete three-channel chip emulators. SID combined waveforms, sync/ring modulation, hardware ADSR and the differing 6581/8580 analog filters are not implemented. AY hardware amplitude/envelope registers and the CPC's analog output circuitry are not modeled. The plugin supplies its existing gate and vocal filters. **SID / Talking pulse** and **CPC / Speech computer** demonstrate the new carriers with the new speech backends.

References: [original SID datasheet transcription](https://www.waitingforfriday.com/?p=661), [GI AY data manual](https://pub.intvprime.com/ba4ef/ie/Programming/AY-3-8910-8912-Programmable-Sound-Generator-Data-Manual.pdf).

## Singing matrix

Speech style preserves the previous voice behavior. Singing sustains voiced vowels/nasals and enables the small control grid: Shape shifts formants, Speed drives vibrato/tremolo, Pitch controls vibrato depth, Glide controls overlapping-note pitch motion, and Level controls tremolo depth. It works with Speech Synth, Phonic Keys and those internal vocoder sources. It does not modify live input audio or Voder. Chip-pitch modes retain their native pitch quantization.

## Phonetic tiles

Select a note on the mapping piano, then click a rounded sound tile to assign it immediately. Selecting another target note only inspects its saved sound. Groups separate vowels, stops, air/hiss consonants, resonants and syllables. The bottom performance piano remains separate. Linear vowel/phonics filling remains an explicit action.

References: [MAME SP0256](https://github.com/mamedev/mame/blob/1ff183fcbd122ffb9ae5eb34c49c9c410ce83aa7/src/devices/sound/sp0256.cpp), [clock correction](https://github.com/mamedev/mame/commit/638224548b67a2b8f4cbc561b38cfef211f122f6), [MAME SC-01A circuit model](https://github.com/mamedev/mame/blob/1ff183fcbd122ffb9ae5eb34c49c9c410ce83aa7/src/devices/sound/votrax.cpp). Attribution and BSD terms are in THIRD_PARTY_NOTICES.md.


## MEA8000 / four formants

Integer 8 kHz synthesis with four cascaded resonators, quantized frequency/bandwidth/amplitude tables and interpolated frames. F4 is fixed at 3500 Hz; F5 and individual formant gains do not apply. 11,840 samples agree exactly with independent pinned MAME fixtures. The wrapper authors frames from our phones, uses deterministic replacement noise, host envelopes and a musical pitch override; original bus/ROM behavior and analog reconstruction are not emulated.

## FOF / singing grains

Independent pitch-synchronous damped sinusoidal packets inspired by CHANT/FOF. Five fixed-Hz formants retain their centres as note pitch changes. Packets use 2 ms cosine onset, exponential decay from bandwidth, 3 ms cosine termination and a 20 ms maximum duration. Pitch is limited to 20–1200 Hz, with 32 slots per formant. Above-band formants fade out at low sample rates. Noise, breath and aspiration are separate sources. Buzz/noise-level and plosive burst-bandwidth controls are applied. Native synthesis runs up to 96 kHz and uses linear interpolation above that rate. This implements the synthesis method; it does not reproduce a historical voice bank.

## Digitalker / waveform codec

The real modes 0, 2 and fresh-frame 3 waveform decoding rules, delta tables and 4-bit DAC amplitude levels are implemented. All 12,288 reference PCM values match exactly. Voiced/pulse frames are newly authored from the phoneme formants; non-looping noise frames are generated for consonants. Pulse mode compensates the repeated half-wave so it follows the requested note. Original 4 MHz native hold-period values are retained in the codec reference, while the playable engine uses continuously variable musical clocking (20–1200 Hz). Transposing that clock also moves its spectral envelope. High-note aliasing and reconstruction are musical extensions, not verified hardware behavior. No original word ROM, mode 1, full ROM command sequencer or device bus is claimed.

## LPC-10 / output codec

A separate serial mono encode/decode effect, selectable below the workspace, applicable to any voice or live input. The BSD LPC10-1.6 core encodes 180 samples at 8 kHz into 54 bits (2400 bit/s), then decodes them. It matches 8640 independent reference bits and 28,800 decoded samples. Prepared polyphase sinc filters handle conversion at host rates from 8–384 kHz, with fixed frame/ring storage and no callback allocation.

This is a communications effect with intentional delay, not a phoneme generator. A gated voiced test measured approximately 166 ms onset delay across the supported rate range; speech-dependent timing varies. Host latency compensation is not requested. The main Mix control precedes this serial codec; bypass retains the direct stereo input. Disabling the codec restores stereo/full bandwidth. Its original low-level decoded silence noise is retained. No modem, bit errors or network transport is simulated.


## FS-inspired / 8+8 operators

An independent engine inspired by the FS1R's documented eight voiced/eight unvoiced operator architecture. Its formant operators use overlapping sine-power packets, with calibrated full -3 dB bandwidth, independent keyboard pitch, four window shapes and real phase modulation. Harmonic FM mode provides eight integer-ratio sine operators. Four routing graphs give eight parallel carriers, four pairs, two four-operator chains, or one eight-operator chain. Operator gains affect both audible output and modulation. Eight independently seeded filtered noise bands provide consonants and breath.

Use Engine character for routing, mode, FM depth, width, window shape and noise level. The first five formant controls edit the lower five operators; three quieter upper bands are authored by the engine. Singing Shape shifts the formants. Packet duration is limited to 20 ms, so minimum effective bandwidth depends on shape (about 72/93/124/171 Hz for p2/p4/p8/p16 before width scaling). Pitch is 20–1200 Hz. A 32-slot pool per operator covers the maximum overlap without stealing. Internal synthesis runs at twice host rate up to a maximum of 96 kHz, with low-pass filtering and interpolation back to the host rate. High index/high note combinations remain a musical synthesis extension, not a measured Yamaha aliasing model.

This is not an FS1R firmware emulator: it does not load Yamaha patches, FSeq data, the original 88 algorithms or ROM voices, and has no hardware-equivalence percentage. Architecture reference: Yamaha FS1R Owner's Manual, pp.8–13 and58–69. The independent packet method follows the sine-power window concept in Yamaha US5138927A; that patent is not evidence of the FS1R's exact internal algorithm.


## Klatt / cascade + parallel

A fixed-storage C++ port of Christian d’Heureuse’s MIT-licensed `klatt-syn`, pinned to `3a1eddd519fec2bea7c5e47237c7047786a23abc`. The six-formant tract combines cascade and parallel branches, a nasal pole/zero, alternating upper parallel signs, aspiration and frication paths, and separate seeded noise histories. Natural KLGLOTT88 and impulse glottal sources, spectral tilt, open-phase breath, flutter and pitch-boundary frame commits follow the reference. The UI exposes source, open fraction, tilt, flutter, parallel balance and aspiration; shared formant gains affect the parallel branch.

Tests compare 768 primitive values and 32,768 complete reference audio samples exactly. Source, MIT license and fixture provenance are included. The wrapper maps our authored phonemes into this tract, supplies a sixth formant, host envelopes and a 20–1200 Hz musical pitch range. At low host rates, out-of-band cascade sections bypass and parallel sections mute for stability. GUI plotting and automatic gain control from the reference demo are omitted. Generic transition/pitch-envelope controls are unavailable in this engine. This is not DECtalk firmware, Perfect Paul, the original 1980 binary, or an original voice-bank reproduction.

## Controls, state and shared output

Unavailable generic controls are dimmed per engine. FOF/FS/Klatt support mixed excitation; Digitalker also supports its distinct pulse codec mode. MEA8000 has three programmable formant centres and fixed F4, with four programmable widths. SC-01A retains its narrower programmable set. FS/FOF formant methods preserve vowel centres with pitch, whereas Digitalker musical transposition moves its waveform spectrum.

The original five-choice `speechEngine` parameter retains normalized automation compatibility. A separate `voiceModel` expansion selects the added engines; the plugin presents one combined ten-choice menu. Older states default expansion and output codec to Off. CC120 clears the shared LPC-10 history, briefly interrupting its output across channels while preserving other channels’ note state. CC123 keeps normal release tails. The reference codec’s low-level encoded-silence noise is retained.
