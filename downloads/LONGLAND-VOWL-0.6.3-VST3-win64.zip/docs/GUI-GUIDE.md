# Using the interface — 0.6.1

The header's **View: Easy / View: Advanced** switch changes which controls are shown. Easy is the initial view. Your sound parameters and assignments are unchanged when switching views. The view choice stays while this editor is open; reopening starts in Easy.

## Assign words to notes

Open **Phonic Keys → Words to keys**. Select a target on the upper mapping piano, type words, then press **Assign words**. The lower piano plays your saved assignments. Preview plays the saved sequence, not unbuilt draft text. The selected note and its current assignment are shown above the mapping piano.

In Speech Synth, **Assign words to a key...** opens this page and copies the typed text into the current target key's draft. It does not compile or replace the saved audio sequence until you press Assign words. Each key keeps its own draft: select another key before typing if you want a different target.

Easy includes one-shot/hold/loop, note pitch, tempo sync and speech rate. Advanced also reveals the phoneme sequence and each step's sound, duration and pitch offset. Phrase playback remains monophonic: the latest mapped key wins.

## Assign single sounds

**Sound tiles** and **Words to keys** are separate, always-visible navigation buttons in Phonic Keys. Select a note, then click a grouped rounded tile to apply it immediately. A tile replaces any phrase assigned to that key. Linear vowels / phonics fills consecutive keys from the next selected starting note. Advanced adds MIDI routing and the **Edit sound** programmer.

## Shape a vowel with the pad

Open **Speech Synth → Vowel touch pad** in either view. Hold a MIDI note or enable **Audition voice**, then drag the dot: left/right changes front/back; up/down changes closed/open. The pad changes the first two formants, not pitch. Engine-specific quantization still applies.

Choose a target in the note selector, name the vowel and press **Save vowel to [note]**. This replaces that key's sound or phrase. Open Phonic Keys to play the saved vowel. **Back to speech** returns to text and vowel buttons.

## Help while working

Hover over controls to display explanations after a short delay. Both pianos explain their roles. **? Help** opens a scrollable built-in guide; **Close help** returns to the previous view. The performance piano stays accessible. Record notes in your DAW using incoming MIDI or its computer-key input; the plugin piano auditions sounds.

Advanced retains access to detailed synthesis and routing. Entering Phonic Keys still defaults to the rounded sound tiles, even after editing a different page. Blender work remains paused. Both effect and instrument use this interface.
