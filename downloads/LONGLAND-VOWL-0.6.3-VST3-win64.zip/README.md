# longland VOWL 0.6.3 — retro speech instrument and effect

Windows x64 **VST3 only**, built with the supplied JUCE 9.0.0. Two products share a classic filterbank vocoder, manual/articulated Voder, programmable formant voice, editable Phonic Keys, **TI 5100, SP0256, SC-01A, MEA8000, FOF, Digitalker, FS-inspired and Klatt synthesis backends**, a separate LPC-10 output codec, and SID/Amstrad AY digital carrier sections. This is a development instrument; the full advanced-engine roadmap is not complete.

Version **0.6.3** renames the products to **longland VOWL** and **longland VOWL Instrument**, removes the plugin recorder buttons and updates Help. Plugin codes, parameter IDs and preset format remain unchanged. The new Blender faceplate is a separate design asset; this build uses the existing JUCE interface.

Version **0.6.1** improves discoverability with **Easy / Advanced**, persistent **Sound tiles / Words to keys** navigation, a direct **Vowel touch pad** route, hover explanations and built-in **? Help**. Speech Synth can copy text to a key draft. See [GUI-GUIDE.md](docs/GUI-GUIDE.md).

Version **0.6.0** adds **MIDI phrase keys and editable phoneme sequences**. In **Phonic Keys → Words to keys**, select a piano note, type words and press **Assign words**. Edit each sound, duration and pitch; choose one-shot, held or looping playback, with optional host-tempo sync. Four phrase presets bring the total to **42**. See [PHRASE-KEYS.md](docs/PHRASE-KEYS.md).

Version **0.5.2** restores the grouped rounded sound tiles whenever you enter **Phonic Keys**. The previous tab's detail or engine panel can no longer hide them. Select a note on the assignment piano, then click a tile to apply its sound immediately. **Edit sound / Sound tiles** switches between the programmer and tiles; clicking **Phonic Keys** again also brings the tiles back.

The **0.5.1** note-run click fix remains included. Connected notes keep their closure/envelope timing; a short 3 ms transition handles retriggers, velocity changes and voice stealing. The new note starts at its MIDI timestamp. Fresh attacks and steady-state synthesis remain unchanged; very short staccato TI notes retain the running core so its startup is not repeatedly interrupted.

## Install

Copy either or both complete directory bundles from `Binaries/Release` to a VST3 folder scanned by your DAW, then rescan:

- **longland VOWL Instrument.vst3** — MIDI instrument, silent audio inputs by default, starts ready to play the TI voice. Recommended for Reason's typing keyboard and speech synthesis.
- **longland VOWL.vst3** — audio effect, preserving the existing plugin identity and sessions. For microphone/audio vocoding, route audio and MIDI to it.

There is no Standalone target or installer. Copy each entire `.vst3` directory, not only its inner DLL. The ZIP includes both bundles, factory presets and notices.

The Windows build uses the Microsoft Visual C++ x64 runtime (MSVC 19.x). This runtime is already present on the build/test computer; it is not bundled in this ZIP.

## Try the speech computer

Load **longland VOWL Instrument**, select its Reason track, press **F4 → Computer Keys**, and play. Choose a cream vowel button in the red panel. **TI / Speak keys**, **TI / Phonic choir**, **TI / Speech into vocoder**, and **TI / Chip pitch** remain available alongside SP0256, SC-01A, singing, SID and CPC sounds. Version 0.5 adds twelve presets for MEA8000, FOF, Digitalker, FS-inspired, Klatt and LPC-10. In Advanced, **Sound details** reveals the full programmer; the performance piano stays visible.

The TI engine models the original chip's LPC synthesis and tables. Its speech sounds are authored approximations; original Speak & Spell vocabulary ROMs are not bundled. See [TI-SPEECH.md](docs/TI-SPEECH.md) for tested fidelity, original versus musical pitch behaviour and exact scope. No unverified percentage of hardware equivalence is claimed.

Type English words in **Speech Synth** and press **Speak**. Choose the voice engine, adjust **Speech rate**, or open **Singing matrix** for shape, speed, vibrato, glide and tremolo. This uses a bundled pronunciation dictionary and authored sounds, with letter-name fallback for unknown words. See [TEXT-SPEECH.md](docs/TEXT-SPEECH.md).

SID and CPC choices are digital carrier sections used by the vocoder, not standalone text-to-speech engines. See [RETRO-ENGINES.md](docs/RETRO-ENGINES.md) for exact implemented sections and reference tests. DECtalk/Perfect Paul and complete SID analogue profiles remain future work.

![TI speech interface](docs/UI-TI-0.5.png)

## Play

- **Vocoder:** put speech on the main audio input. The internal saw carrier runs at 110 Hz by default. Choose **Carrier pitch mode: MIDI keyboard** to play pitch; **Fixed Hz** uses the frequency slider. The **Vocoder speech source** selects live Audio input, Voice Synth, Voder or Phonic Keys internally. MIDI controls oscillator carrier pitch; enable MIDI gate to silence the carrier between notes. The optional sidechain supplies the External input carrier. Consonant detail intentionally passes some high-passed modulator audio and can sound even when the carrier is gated.
- **Voder:** send MIDI or enable Continuous Voder. Manual mode uses ten channel levels; Articulated mode maps mouth/tongue/lip controls to those channels. Consonant burst triggers a short shaped-noise transient.
- **Voice Synth:** play MIDI, or enable Audition voice. Edit five formants and use the vowel XY pad as an abstract musical control. Choose a key in Phonic Keys, return here, name the sound and save the vowel to that key.
- **Phonic Keys:** select the target note on the labeled assignment piano, then click a rounded sound tile to apply it immediately. Tiles are grouped into vowels, stops, air/hiss, resonants and syllables. The factory-sound dropdown also applies immediately. Selecting a note alone inspects it without overwriting it. Edits save automatically; Clear key disables it. **Edit sound** opens the full programmer; **Sound tiles** returns to the rounded squares. Use the separate bottom piano to perform.
- **Linear phonics:** choose **Linear vowels** (10 sounds) or **Linear phonics** (49 sounds) in the assignment action menu, then pick the first key. Consecutive semitones receive A → AH → EH → EE → IH → OH → OO → UH → AW → ER, followed by consonants and syllables in the full option. A is an EH-to-EE diphthong. Filling stops at MIDI 127; mappings outside the filled range stay intact. The next click fills again while that action remains selected. Use the separate bottom piano to perform without remapping.
- **Keyboard pitch:** enable **Pitch selected sound** in Phonic Keys and choose **Pitched sound / bank key** (or select it with the assignment piano). Every performance key plays that one speech sound at its musical pitch. Use **PHONIC / Keyboard pitch** for a ready-made setup. **VOCODER / Voice Synth to keys** and **VOCODER / Audio to keys** demonstrate pitched vocoding. Noise carriers/unvoiced sounds have no defined musical pitch; external carrier audio is not pitch-shifted.

MIDI modes: fixed-pitch key assignments; split speech (notes below the split select articulation, notes at/above it play pitch); and pitched phonemes (each key selects speech and pitch). The default split is MIDI 60. One voice gives a single moving tract; up to eight voices provide chords. Velocity controls energy, pitch wheel spans ±2 semitones, CC1 moves the formants, channel/poly pressure adds breath in Formant mode (up to 20% amplitude in TI mode), and CC64 sustains. Conventional MIDI channels remain independent. On-screen auditions use channel 16. MPE is not implemented.

Factory presets reset all audio parameters and restore the factory key bank. **Save preset** stores parameters, all custom mappings, both syllable elements, phrase-key sequences and drafts, typed speech and the selected key in a `.vlab` file. The `Factory` folder contains 42 exported presets and the readable factory-bank XML. XML is a data reference; the preset load button accepts `.vlab` files.

![Grouped rounded note-assignment tiles](docs/UI-Phonic-Tiles-0.6.png)

![Phrase assignment and sequence editor](docs/UI-Phrase-Keys-0.6.png)

## New voice engines

Choose **MEA8000** for quantized four-formant computer speech, **FOF** for pitch-synchronous singing grains, or **Digitalker** for encoded waveform speech. **FS-inspired** provides eight voiced and eight noise operators; **Engine character** opens its formant/FM, routing, window, depth, width and breath controls. **Klatt** provides cascade/parallel speech, natural or impulse glottal sources, open fraction, tilt, flutter, balance and aspiration. The Klatt formant-gain controls affect its parallel branch; use the balance control to hear them clearly.

The shared **Output codec / mono** menu enables **LPC-10** after the main mix. It adds approximately **166 ms** of intentional communications delay and folds processed audio to mono; Off preserves the normal stereo path. To encode incoming audio alone, choose the effect and set Dry/Wet to dry before enabling the codec. Host bypass stays dry. CC120 flushes the shared encoded stream, briefly interrupting that stream across channels while preserving other channels' note state; CC123 allows releases. LPC-10 retains the reference codec's low-level noise floor.

FOF, Digitalker, FS and Klatt use a 20–1200 Hz musical pitch range. High notes above it clamp to the maximum. Their performance piano ends at D6; Phonic Keys still stores all 128 MIDI mappings. Controls without an implementation in the selected engine are dimmed. Legacy five-way engine automation retains its original mapping; expanded voices use a separate **Voice expansion** host parameter behind the unified menu.

These are tested synthesis implementations with authored speech data. FS-inspired is an architectural interpretation, not an FS1R firmware/patch/FSeq clone; the Klatt Public address preset is an original sound, not DECtalk or a named government voice. See [RETRO-ENGINES.md](docs/RETRO-ENGINES.md) for reference scope.

![FS engine controls](docs/UI-FS-0.5.png)

## Playing and recording in Reason

The bottom performance piano auditions the current sound in every mode. Record and Save MIDI controls have been removed. Record notes using Reason's sequencer with Reason Computer Keys or an external MIDI keyboard. Select the instrument track and enable Master Keyboard Input; F4 opens Computer Keys.

Reason does not capture the plugin's on-screen piano into its sequencer or accept VST-generated MIDI output. The plugin piano remains useful for auditioning sounds. Phrase phonemes generate audio; their incoming trigger notes are the notes recorded by the host.

## Build and validation

See [BUILD.md](docs/BUILD.md) for exact CMake/Visual Studio instructions, [STATUS.md](docs/STATUS.md) for honest scope, and [VALIDATION.md](docs/VALIDATION.md) for test coverage and remaining verification gaps. The product name has one definition in `cmake/Product.cmake`.

The current toolchain is VS2026/MSVC 19.51 because VS2022 is not installed. A VS2022 x64 preset is supplied but has not been run here. Dependencies build offline: the LPC-10 C codec is vendored and the Klatt synthesis core is ported with its MIT notice. FS operators use an internal rate of up to twice the host rate, capped at 96 kHz. Digitalker renders authored encoded waveforms. Only implemented engines appear in the menus.
