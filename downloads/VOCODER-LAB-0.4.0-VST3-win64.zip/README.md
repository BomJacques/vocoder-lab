# VOCODER LAB 0.3 — TI speech, instrument and effect

Windows x64 **VST3 only**, built with the supplied JUCE 9.0.0. Two products share a classic filterbank vocoder, manual/articulated Voder, programmable formant voice, editable Phonic Keys, **TMS5100, SP0256 and SC-01A synthesis backends**, and SID/Amstrad AY digital carrier sections. This is a development instrument; the full advanced-engine roadmap is not complete.

## Install

Copy either or both complete directory bundles from `Binaries/Release` to a VST3 folder scanned by your DAW, then rescan:

- **VOCODER LAB INSTRUMENT.vst3** — MIDI instrument, silent audio inputs by default, starts ready to play the TI voice. Recommended for Reason's typing keyboard and speech synthesis.
- **VOCODER LAB.vst3** — audio effect, preserving the existing plugin identity and sessions. For microphone/audio vocoding, route audio and MIDI to it.

There is no Standalone target or installer. Copy each entire `.vst3` directory, not only its inner DLL. The ZIP includes both bundles, factory presets and notices.

The Windows build uses the Microsoft Visual C++ x64 runtime (MSVC 19.x). This runtime is already present on the build/test computer; it is not bundled in this ZIP.

## Try the speech computer

Load **VOCODER LAB INSTRUMENT**, select its Reason track, press **F4 → Computer Keys**, and play. Choose a cream vowel button in the red panel. **TI / Speak keys**, **TI / Phonic choir**, **TI / Speech into vocoder**, and **TI / Chip pitch** remain available alongside eight new SP0256, SC-01A, singing, SID and CPC presets. **Sound details** reveals the full programmer; the performance piano and MIDI recorder stay visible.

The TI engine models the original chip's LPC synthesis and tables. Its speech sounds are authored approximations; original Speak & Spell vocabulary ROMs are not bundled. See [TI-SPEECH.md](docs/TI-SPEECH.md) for tested fidelity, original versus musical pitch behaviour and exact scope. No unverified percentage of hardware equivalence is claimed.

Type English words in **Speech Synth** and press **Speak**. Choose the voice engine, adjust **Speech rate**, or open **Singing matrix** for shape, speed, vibrato, glide and tremolo. This uses a bundled pronunciation dictionary and authored sounds, with letter-name fallback for unknown words. See [TEXT-SPEECH.md](docs/TEXT-SPEECH.md).

SID and CPC choices are digital carrier sections used by the vocoder, not standalone text-to-speech engines. See [RETRO-ENGINES.md](docs/RETRO-ENGINES.md) for exact implemented sections and reference tests. DECtalk/Perfect Paul and complete SID analogue profiles remain future work.

![TI speech interface](docs/UI-TI-0.4.png)

## Play

- **Vocoder:** put speech on the main audio input. The internal saw carrier runs at 110 Hz by default. Choose **Carrier pitch mode: MIDI keyboard** to play pitch; **Fixed Hz** uses the frequency slider. The **Vocoder speech source** selects live Audio input, Voice Synth, Voder or Phonic Keys internally. MIDI controls oscillator carrier pitch; enable MIDI gate to silence the carrier between notes. The optional sidechain supplies the External input carrier. Consonant detail intentionally passes some high-passed modulator audio and can sound even when the carrier is gated.
- **Voder:** send MIDI or enable Continuous Voder. Manual mode uses ten channel levels; Articulated mode maps mouth/tongue/lip controls to those channels. Consonant burst triggers a short shaped-noise transient.
- **Voice Synth:** play MIDI, or enable Audition voice. Edit five formants and use the vowel XY pad as an abstract musical control. Choose a key in Phonic Keys, return here, name the sound and save the vowel to that key.
- **Phonic Keys:** select the target note on the labeled assignment piano, then click a rounded sound tile to apply it immediately. Tiles are grouped into vowels, stops, air/hiss, resonants and syllables. The factory-sound dropdown also applies immediately. Selecting a note alone inspects it without overwriting it. Edits save automatically; Clear key disables it. Sound details exposes the full programmer. Use the separate bottom piano to perform.
- **Linear phonics:** choose **Linear vowels** (10 sounds) or **Linear phonics** (49 sounds) in the assignment action menu, then pick the first key. Consecutive semitones receive A → AH → EH → EE → IH → OH → OO → UH → AW → ER, followed by consonants and syllables in the full option. A is an EH-to-EE diphthong. Filling stops at MIDI 127; mappings outside the filled range stay intact. The next click fills again while that action remains selected. Use the separate bottom piano to perform without remapping.
- **Keyboard pitch:** enable **Pitch selected sound** in Phonic Keys and choose **Pitched sound / bank key** (or select it with the assignment piano). Every performance key plays that one speech sound at its musical pitch. Use **PHONIC / Keyboard pitch** for a ready-made setup. **VOCODER / Voice Synth to keys** and **VOCODER / Audio to keys** demonstrate pitched vocoding. Noise carriers/unvoiced sounds have no defined musical pitch; external carrier audio is not pitch-shifted.

MIDI modes: fixed-pitch key assignments; split speech (notes below the split select articulation, notes at/above it play pitch); and pitched phonemes (each key selects speech and pitch). The default split is MIDI 60. One voice gives a single moving tract; up to eight voices provide chords. Velocity controls energy, pitch wheel spans ±2 semitones, CC1 moves the formants, channel/poly pressure adds breath in Formant mode (up to 20% amplitude in TI mode), and CC64 sustains. Conventional MIDI channels remain independent. On-screen auditions use channel 16. MPE is not implemented.

Factory presets reset all audio parameters and restore the factory key bank. **Save preset** stores parameters, all custom mappings, both syllable elements, typed phrase and the selected key in a `.vlab` file. The `Factory` folder contains 26 exported presets and the readable factory-bank XML. XML is a data reference; the preset load button accepts `.vlab` files.

## MIDI recording and Reason

The bottom performance piano is available in every mode. **Record MIDI** starts a new take; **Stop MIDI** stops it; **Save MIDI...** writes a standard `.mid` file. It captures incoming MIDI and on-screen notes, including bend/controllers, using host tempo (120 BPM fallback), with held notes/sustain closed on export. The take starts at zero and follows processed time, not song position or loop jumps. Record before playing notes. Retaking replaces the captured take; save it before retaking or removing the plugin. Plugin presets do not contain recorded takes. Capture is bounded to 65,536 events and stops if full; SysEx and parameter automation are not recorded.

**Reason FX setup:** the VOCODER LAB effect is a MIDI-capable audio effect, so create a sequencer track for the VOCODER LAB rack device, give that track a note lane and keyboard focus, and record your hardware keyboard or Reason's own on-screen keyboard on that track. Audio still goes to the vocoder's main input; MIDI must target VOCODER LAB, not only the source instrument. See Reason's [track menu reference](https://docs.reasonstudios.com/reason14/menu-and-dialog-reference).

Reason does not record a VST's internal on-screen keyboard into its sequencer and does not accept VST-generated MIDI output. Use the plugin's **Record MIDI → Stop MIDI → Save MIDI** for those performances. Import the file through Reason's **File → Import MIDI File...**, then move the imported note clips onto the VOCODER LAB note lane (Reason initially creates ID8 tracks). Mixed hardware and on-screen performances can import as separate tracks because channels are preserved; move each relevant clip to VOCODER LAB. Reason may import tempo data too; import into a spare song and copy the clip if you want to preserve an existing song's tempo. Sources: [VST support](https://docs.reasonstudios.com/reason14/working-with-vst-plugins), [MIDI import](https://docs.reasonstudios.com/reason14/song-file-handling).

The updated VST3 also exposes MIDI output for hosts that support it. Host input events pass through; on-screen events are merged. This does not change Reason's host limitation.

## Build and validation

See [BUILD.md](docs/BUILD.md) for exact CMake/Visual Studio instructions, [STATUS.md](docs/STATUS.md) for honest scope, and [VALIDATION.md](docs/VALIDATION.md) for test coverage and remaining verification gaps. The product name has one definition in `cmake/Product.cmake`.

The current toolchain is VS2026/MSVC 19.51 because VS2022 is not installed. A VS2022 x64 preset is supplied but has not been run here. No external DSP library, network dependency fetch, blanket oversampling, sample-based voice or placeholder engine is used.
