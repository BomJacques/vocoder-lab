# Status

WORKING
- Version 0.4.0: effect and instrument VST3 products; nine CTest suites in Debug and Release, including actual DLL discovery/processing for both products.
- Classic filterbank with 8/10/16/20/32/64 bands; eleven carrier choices including external audio; consonant paths; stereo envelopes; topology/carrier crossfades; smoothed bypass/mix/gain; metering.
- Manual/articulated Voder; programmable five-formant voice, four excitation types, nasal/noise/closure/burst/envelopes; vowel XY designer and save to key.
- 48 factory speech sounds, all 128 editable mappings, two-element syllables, fixed/split/pitched MIDI modes, 1–8 voices, stealing, sustain, bend/pressure/mod-wheel expression and articulation interpolation.
- Charcoal/amber resizable GUI, retro TI speech panel, editable programmer, 26 factory presets and complete custom-map user preset/state serialization.
- TI 5100 synthesis core with original lookup tables, serial frame decoding, integer lattice/interpolation/noise behavior, authored phoneme conversion, musical/chip-table pitch modes and up to eight voices. See TI-SPEECH.md for exact scope and reference tests.

- 0.4 adds SP0256 integer synthesis, SC-01A circuit synthesis, SID digital saw/pulse/triangle and AY tone/noise carriers; a singing matrix; grouped immediate-assignment tiles; and offline English typed phrases on all speech backends. See RETRO-ENGINES.md and TEXT-SPEECH.md for limitations. No original SP/SC phone ROMs or complete SID/AY device emulation are included.

- 0.2 update: selected-sound keyboard pitch, internal Voice Synth/Voder/Phonic-to-vocoder routing, shared performance piano, MIDI through/output, built-in MIDI capture/export, automatic labeled-piano assignments, and linear vowel/full-phonics fill.
- Reason-specific usage is documented in README. Reason's own VST MIDI-output restriction remains; built-in file capture is the workaround.

PARTIAL
- Full gauntlet roadmap; this release ends at the reliable speech/MIDI milestone.
- Nasal model is a parallel resonance and oral attenuation, not a complete nasal anti-resonance tract.
- Basic envelope display; dedicated formant/spectral-history visualizations are future work.

NOT IMPLEMENTED
- Live LPC analysis, FFT/phase/cepstral vocoders, DECtalk/Perfect Paul, complete SID analogue profiles, spectral memory/shear/physics/matrix/multicarrier, sequencer, MPE.

KNOWN ISSUES
- Only VS2026 is installed; VS2022 build cannot be verified here.
- Standalone excluded by updated user instruction.
- No pluginval/full-DAW session or subjective listening evaluation. Reason typing-keyboard playback is ready for the user's instrument test; it has not been verified in a live Reason session. See VALIDATION.md.
- TI synthesis does not include the original vocabulary ROM, toy CPU, original text/word firmware, analogue speaker model or live LPC analysis. Tested reference agreement is not a claim of exhaustive hardware equivalence.
- Conservative 20-second host tail accommodates maximum filterbank release.

DELIVERY
- Source/CMake/VS presets: this project folder; Release VST3 bundles: `Binaries/Release/VOCODER LAB.vst3` and `Binaries/Release/VOCODER LAB INSTRUMENT.vst3`.
- Factory data: `Factory/` (26 presets and XML phoneme bank). Tests: `Tests/`.
- Spectral implementation: bounded envelope frames and live display only; no spectral-memory/physics claims.
- See VALIDATION.md for current regression results and independently checked synthesis sections.
- Next priorities: listening/Reason testing, phrase sequencing and finer voice tuning, then reference-backed DECtalk and full SID profiles. Blender remains paused. See ../../VocoderLab-Plan.md.
