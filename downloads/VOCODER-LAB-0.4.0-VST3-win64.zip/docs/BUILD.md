# Build

Requires a local JUCE source tree, CMake >=3.22, Windows SDK, Visual Studio C++ desktop workload, x64 MSVC and C++20. No Projucer or dependency download.

From a Visual Studio 2022 Developer PowerShell in the project directory:

```powershell
$env:JUCE_DIR = 'C:\Users\HAL 4020\Downloads\juce-9.0.0-windows\JUCE'
cmake --preset vs2022
cmake --build --preset debug --parallel 4
cmake --build --preset release --parallel 4
ctest --test-dir build/vs2022 -C Debug --output-on-failure
ctest --test-dir build/vs2022 -C Release --output-on-failure
```

VS2026 is also supported with `cmake --preset vs2026`, then `cmake --build build/vs2026 --config Debug` (or Release).

The included script can discover Visual Studio's bundled CMake even when CMake is absent from PATH:

```powershell
.\Build.ps1 -JucePath 'C:\Users\HAL 4020\Downloads\juce-9.0.0-windows\JUCE' -VisualStudio 2026
```

This run's intermediate build is `C:\Users\HAL 4020\Documents\Codex\2026-10-06\ca\work\build`. Packaged Release VST3 files are in `Binaries/Release`. Tests and build directories are not installed or included in the VST3 bundle.

Product identity is defined only in `cmake/Product.cmake`. Parameter IDs and plugin codes are persistent identities.

Artifact: `<build>/VocoderLab_artefacts/<configuration>/VST3/VOCODER LAB.vst3`. The VST3 is a directory bundle; copy the entire bundle to a VST3 host scan directory. Builds do not install plugins automatically. Standalone is excluded per the user's updated instruction.

The instrument is a second VST3 target, `VocoderLabInstrument_VST3`, built from the same source and shared DSP library. Its artifact is `<build>/VocoderLabInstrument_artefacts/<configuration>/VST3/VOCODER LAB INSTRUMENT.vst3`. Product names and distinct plugin codes live in `cmake/Product.cmake`; target-specific generated headers keep the wrappers separate. The original FX class IDs remain unchanged. Both Debug and Release builds include the nine test suites.

Initial environment: empty workspace, JUCE 9.0.0, VS2026 Community 18.8.2, MSVC 14.51, bundled CMake 4.3.1. VS2022 and pluginval were not found on PATH. VS2022 compatibility is supplied as a preset, not yet verified on that compiler.
