# Typed speech

In **Speech Synth**, choose Formant, TI keyboard, TI chip pitch, SP0256, or SC-01A. Type English words and press **Speak** (or Enter). **Stop speech** releases the phrase. The voice pitch slider controls phrase pitch; **Speech rate** runs from 0.5 to 2 times normal speed. The singing matrix also applies. Keyboard notes can sound alongside the phrase.

Words use the bundled CMU Pronouncing Dictionary, mapped to authored phonemes. No network or external speech service is used. Unknown words are spelled as letter names; digits are read individually. Punctuation adds pauses. The status line reports unknown words, unsupported characters and truncation. Input is limited to 256 ASCII bytes and 512 speech steps; non-English text is unsupported. Pronunciation, stress timing and diphthong movement are deliberately simple and remain subject to listening refinement.

Text and rate are saved in projects and user presets. Loading a state stops speech and does not autoplay it. Factory selection clears the phrase. Transport reset and MIDI all-notes/all-sound-off stop playback. Speak starts immediately when the host processes audio; this first version has no timeline, note-triggered phrase sequencing or lyric-to-note mapping. Generated phonemes are audio, not generated MIDI notes.

To vocode a phrase, start it in Speech Synth and switch to Vocoder with **Voice Synth** as the speech source. Play carrier notes if MIDI gate is enabled. The phrase continues across those mode changes.

The pronunciation dictionary is an added frontend, not the original Speak & Spell vocabulary ROM, AL2 allophone ROM or SC-01A phone ROM. Chip synthesis scope is described in TI-SPEECH.md and RETRO-ENGINES.md. No full-machine or 99% sound-equivalence claim is made.

CMUdict revision and redistribution terms are included in CMUDICT-REVISION.txt and CMUDICT-LICENSE.txt. The dictionary is embedded in both VST3 bundles; its file is included in source packages. Dictionary indexing and phrase compilation happen off the audio thread. The callback consumes a fixed-capacity snapshot and renders without dictionary access.
