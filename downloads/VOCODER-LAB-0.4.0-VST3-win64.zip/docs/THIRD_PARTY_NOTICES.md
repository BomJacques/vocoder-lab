# Third-party notices

The TI LPC tables and synthesis arithmetic/timing are adapted from the BSD-3-Clause
files `src/devices/sound/tms5110.cpp`, `tms5110.h`, and `tms5110r.hxx` in MAME.
Pinned source: https://github.com/mamedev/mame/tree/1ff183fcbd122ffb9ae5eb34c49c9c410ce83aa7/src/devices/sound
No MAME device framework or Speak & Spell vocabulary ROM is included.

The SP0256 synthesis section and reference fixtures are adapted from MAME
`src/devices/sound/sp0256.cpp` (Joseph Zbiciak, Tim Lindner). The SC-01A circuit
filter builders and analog path are adapted from MAME `votrax.cpp` and `votrax.h`
(Olivier Galibert), at the same pinned revision. Those files are also BSD-3-Clause.
Original AL2 and SC-01A phone ROMs are not included.

Copyright holders: Frank Palazzolo, Jarek Burczynski, Aaron Giles, Jonathan Gevaryahu, Couriersud, Joseph Zbiciak, Tim Lindner, Olivier Galibert

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT
HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

## CMU Pronouncing Dictionary

Data/cmudict.dict is embedded in both products. Copyright Carnegie Mellon University 1993�2015. Full terms are reproduced in CMUDICT-LICENSE.txt; the pinned revision is recorded in CMUDICT-REVISION.txt. These documents accompany binary and source distributions.
