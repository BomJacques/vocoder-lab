# Retro synthesis backends

These backends are separate implementations. Their authored phoneme banks and musical pitch controls are extensions; they do not contain original toy/computer speech ROMs. No blanket percentage of original-device fidelity is claimed. Core reference tests and voice-data authenticity are different checks.

## SP0256 / authored speech

The synthesis section implements six cascaded two-pole integer stages, asymmetric coefficient quantization, signed 16-bit stage wrapping, impulse/noise excitation, the 15-bit noise generator, excitation-boundary delay resets and amplitude/period interpolation registers. Sustained software register frames replace the AL2 ROM and microsequencer. There is no AL2 allophone ROM, serial instruction decoder or bus emulation.

An independent extraction of MAME's synthesis functions supplies 5,345 emitted samples covering twelve register scenarios. Tests compare the raw signed filter result and an explicitly defined signed 8-bit output quantizer. The pinned reference enables its higher-resolution output; its disabled low-resolution branch shifts an unsigned value before sign conversion, so this build does not reproduce that branch's negative-sample error. The quantizer is signed floor division by 16, saturation to -128…127, then multiplication by 256.

The wrapper uses 3.12 MHz / 312 = 10 kHz, following upstream's divider correction in commit `638224548b67a2b8f4cbc561b38cfef211f122f6`. The older primitive fixture reference's divider of 336 is not used for playback. A voiced period is register value + 1 samples; keyboard pitches retain this integer resolution. Formants map to stable, quantized resonator coefficients with a sixth identity section. Host envelopes, amplitude expression and reconstruction filtering surround the native core.

## SC-01A / circuit voice

The analog synthesis path is adapted from the pinned MAME SC-01A circuit model: measured capacitor-ratio filters, glottal waveform, separate voiced/noise paths, F1/F2/F3/F4 sections, final low-pass and noise shaping. The model runs at 40 kHz, with a 20 kHz noise/control clock. The filter-control interpolators use the reference integer recurrence.

Authored formant frequencies select nearby capacitor-control codes; F2 bandwidth selects its Q code. MIDI pitch uses a musical phase extension. Host attack, sustain, release and burst envelopes replace the original phone-duration/controller machinery. No original SC-01A phone ROM, four-step inflection input model or complete digital controller is included.

The reference neutralizes an unstable F2 noise-injection branch and uses an empirical 150/4000 correction in the final low-pass. This build retains those limitations; noise still enters the later mixed path. Filter-control commits happen on the 20 kHz control tick instead of the original pitch-synchronized commit points, as part of the controller extension. It is a circuit-reference model, not a claim of complete analog silicon equivalence. F1/F3 bandwidth, F4/F5 programming, independent formant gains, nasality, breath and pitch-envelope controls from the generic Formant engine do not apply here.

## SID and Amstrad carrier sections

The carrier menu adds SID digital saw, pulse and triangle generators, plus Amstrad CPC AY-3-8912 tone and noise. They have distinct register-clock implementations rather than reusing the existing floating-point oscillators. The SID section uses a 24-bit phase accumulator, 16-bit frequency register and 12-bit waveform output at a 985,248 Hz clock. The AY section uses the CPC's 1 MHz clock, 12-bit tone divider and 17-bit noise generator. Native clock samples are averaged into host samples.

These are oscillator/carrier sections, not complete three-channel chip emulators. SID combined waveforms, sync/ring modulation, hardware ADSR and the differing 6581/8580 analog filters are not implemented. AY hardware amplitude/envelope registers and the CPC's analog output circuitry are not modeled. The plugin supplies its existing gate and vocal filters. **SID / Talking pulse** and **CPC / Speech computer** demonstrate the new carriers with the new speech backends.

References: [original SID datasheet transcription](https://www.waitingforfriday.com/?p=661), [GI AY data manual](https://pub.intvprime.com/ba4ef/ie/Programming/AY-3-8910-8912-Programmable-Sound-Generator-Data-Manual.pdf).

## Singing matrix

Speech style preserves the previous voice behavior. Singing sustains voiced vowels/nasals and enables the small control grid: Shape shifts formants, Speed drives vibrato/tremolo, Pitch controls vibrato depth, Glide controls overlapping-note pitch motion, and Level controls tremolo depth. It works with Speech Synth, Phonic Keys and those internal vocoder sources. It does not modify live input audio or Voder. Chip-pitch modes retain their native pitch quantization.

## Phonetic tiles

Select a note on the mapping piano, then click a rounded sound tile to assign it immediately. Selecting another target note only inspects its saved sound. Groups separate vowels, stops, air/hiss consonants, resonants and syllables. The bottom performance piano remains separate. Linear vowel/phonics filling remains an explicit action.

References: [MAME SP0256](https://github.com/mamedev/mame/blob/1ff183fcbd122ffb9ae5eb34c49c9c410ce83aa7/src/devices/sound/sp0256.cpp), [clock correction](https://github.com/mamedev/mame/commit/638224548b67a2b8f4cbc561b38cfef211f122f6), [MAME SC-01A circuit model](https://github.com/mamedev/mame/blob/1ff183fcbd122ffb9ae5eb34c49c9c410ce83aa7/src/devices/sound/votrax.cpp). Attribution and BSD terms are in THIRD_PARTY_NOTICES.md.
