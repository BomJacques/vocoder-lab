# Roadmap

Build gates: foundation → classic filterbank → architecture audit → Voder → programmable formant synthesis → Phonic Keys → transitions → polyphony/MIDI audit → LPC → FFT → spectral memory and transformations → final validation.

Each published engine must have distinct working DSP. Unimplemented models remain in this document, never in menus. Later candidates: LPC analysis/synthesis, FFT envelope transfer, phase cross synthesis, cepstral envelopes, spectral freeze/history/time shear, envelope physics/diffusion/gravity, routing matrix, multicarrier, sequenced speech and MPE.

Current delivery completes the first functional vocoder and speech/MIDI milestone. The next logical phase is a stable LPC analysis/synthesis engine with reflection-coefficient stability checks, independent test vectors and CPU profiling, followed by FFT envelope transfer with explicit windowing latency. These require their own analysis/reconstruction and host-compensation work; they are not approximated with EQ presets. Retro speech models and the Clean/Toy macro follow after those engines. SpectralFrame and IVocoderEngine are the integration boundaries for later algorithms and spectral memory. No memory, shear, physics or routing-matrix controls are exposed before those systems exist.
