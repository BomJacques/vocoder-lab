# Validation

Updated on 7 October 2026 with local JUCE 9.0.0, VS2026 Community 18.8.2, MSVC 19.51.36252, Windows SDK 10.0.28000.0 and CMake 4.3.1.

Historical version 0.4.0: Debug **9/9 tests (16.42 s)** and Release **9/9 (2.83 s)**, exit 0. Both VST3 variants compiled without compiler warnings in the final builds. The independent final review found a quoted-word pronunciation bug; it is fixed with quoted-word and contraction regressions. No confirmed blocking findings remain.

## 0.5.2 rounded assignment tiles

Final gate: Debug **13/13 in 47.51 s**, Release **13/13 in 7.41 s**, exit 0, with no compiler warnings/errors. Both VST3 manifests report 0.5.2. The actual rounded tile and Edit sound views were rendered and visually inspected at 1100 × 950; the complete five-group layout, mapping piano and performance piano are visible. All 38 factory presets are exported. The 0.5.1 audio fixes remain unchanged. Live Reason retesting remains pending.

The shared detail flag and persistent Engine character panel could hide the Phonic Keys tiles after tab navigation. Entering Phonic Keys now restores its grouped tile view; the timer also detects mode changes made through host automation or state recall. Clicking the already-selected tab returns to tiles. Edit sound / Sound tiles exposes both views explicitly.

The actual-editor regression checks all 49 tiles and their ancestor visibility, positive square bounds inside the panel at 1100 × 950 and 1600 × 1300, detail/engine/singing navigation, same-tab return, host parameter changes, state recall, and immediate assignment to only the selected note. The existing mapping and audio regressions remain in place. The headless editor is explicitly visible and timer callbacks are dispatched with a bounded wait; no desktop peer is needed.

## 0.5.1 note-transition fix

Final gate: Debug **13/13 in 41.43 s**, Release **13/13 in 6.11 s**, exit 0, with no compiler warnings/errors. Both plugin manifests report 0.5.1. The user reported clicks across engines during keyboard runs. Independent paired-control renders reproduced abrupt steps up to 0.79 full scale at note boundaries. Connected legato notes had been resetting the closure clock; hard retriggers also discarded audible tails, and velocity changed immediately. Connected nonplosive notes now keep their envelope/closure timing. SP keeps its impulse timing and MEA interpolates its new frame. An active speech voice uses a fixed 3 ms smoothstep transition from its last output sample into the new core output; a second event during that interval starts from the current mixed sample. MIDI scheduling is unchanged and this is not a continuous filter. The short transition can soften the first few milliseconds of a retrigger.

Across all ten backends, independent checks measured zero first-sample boundary jumps for connected/repeated notes, velocity changes, next notes, active articulation and mono fallback. In the measured eight-voice stealing case, the largest extra step relative to uninterrupted control fell from 0.2303 to 0.00684; other continuing voices still have their natural waveform slopes. Rapid retriggers at 0.5 ms intervals remain finite and continuous. Fresh silent-onset output matches the corresponding raw backend for 4096 samples. Explicit reset/CC120 still produces immediate silence. Release-tail retriggers preserve the running core while restarting their envelope attack, keeping very short TI staccato notes audible.

VoiceTests covers envelope continuity, authored plosive closure, all ten engines at 8/48/96 kHz, repeated events during transitions, bounded output, completed release and reset silence. PluginTests verifies MIDI note-on at sample offset 23 and the GUI keyboard at the block boundary, with callback allocation guards. Existing actual-VST3 fast on/off tests retain their timings and minimum-energy requirement. Live Reason confirmation and subjective listening of the patched build remain pending.

| Suite | Coverage |
| --- | --- |
| PluginTests | Prepare at 22.05/44.1/48/96 kHz; 0/1/17/128/511/2048-sample blocks; parameter and custom two-element speech-map recall; invalid state header; automation and MIDI; dry bypass; transport reset; zero-length note-off; GUI queue overflow; editor creation/destruction and resize; guarded callback C++ `new` calls and Debug CRT allocation/reallocation hook |
| TextSpeechTests | Dictionary pronunciations, punctuation, contractions and quoted words; unknown-word spelling; digit reading; input/step limits; audible, bounded phrase rendering across all ten speech backends at 8/44.1/48/96 kHz; completion and stop |
| ExpandedVoiceTests | 11,840 MEA8000 reference samples; 12,288 Digitalker reference samples; FOF packet equation, fixed formant centres, bandwidth, buzz/noise/burst controls; all authored sounds, rate coverage, release and high-rate FOF |
| Lpc10Tests | 8,640 exact encoded bits and 28,800 decoded reference samples; independent/reset states, 8–384 kHz conversion, nonfinite input and rapid toggle continuity |
| FsVoiceTests | Calibrated packet bandwidth, analytic PM sideband amplitudes, sine-table wrap boundaries, routing differences, deterministic noise/reset, all authored phones, bounded overlap and release |
| KlattTests | 768 primitive and 32,768 complete reference samples; ported natural/impulse sources, tract and noise paths; authored wrapper, parameter bounds and release |
| RetroVoiceTests | 5,345 SP0256 raw/quantized reference samples; 10,240 SC-01A direct-circuit samples; authored SP/SC phonemes at four rates; singing and release; SID register phase wrapping, AY divider/noise sequence and finite bounded carrier output |
| DspTests | Bandpass selectivity; 8/10/16/20/32/64 resolutions; 22.05–192 kHz; silence, impulse, noise and parameter extremes; five carriers; manual/articulated Voder; all 48 factory sounds; four voice excitations; morph and note release |
| VoiceTests | Eight-voice bound/stealing; overlapping channel notes; CC120 scope; sustain; mono last-note return; split morph; repeated split plosives; reducing polyphony to mono; concurrent triple-buffer snapshot coherence |
| TiLpcTests | Exact agreement with 2,048 primitive oracle samples and 1,400 aligned full-frame samples from pinned MAME code; serial frame parsing, repeat, silence, stop and truncation; all authored sounds; 8/44.1/48/96 kHz; musical octave pitch; eight-voice stealing and panic |
| InstrumentTests | Zero-input TI startup, all internal speech routes, stale-buffer silence, dry/bypass silence, MIDI note/release, callback allocation guard, new/legacy state, optional input buses and editor creation |
| Vst3Smoke | Loads the actual VST3 DLL, enumerates classes, instantiates the audio component, checks MIDI and sidechain buses, negotiates mono/stereo, processes at 44.1/96 kHz with varying blocks, verifies finite output and zero latency, stops/deactivates |
| InstrumentVst3Smoke | Same actual-DLL checks for the distinct instrument product, including inactive input buses, empty input arrangements, MIDI input/output and event sample timing |

Release benchmark (wall clock, 48 kHz, 10 seconds of generated audio): stereo 64-band bank approximately 0.59 seconds / **5.9% of one real-time core budget**; eight formant voices approximately 0.35 seconds / **3.5%**. These isolate each DSP subsystem, exclude GUI and DAW overhead, and are a local observation rather than a performance guarantee. Run `DspBenchmark.exe` to reproduce.

The allocation guard detects C++ `new`/`new[]`; on MSVC Debug it also uses the CRT allocation/reallocation hook. It is not a general OS heap profiler. Independent source audits also reviewed the callback graph, fixed storage, channel state and snapshot publication.

Editor images are rendered from the real JUCE component. VST3 host validation uses the included minimal test host; pluginval and a full DAW session have not been run. Real audio-device audition, subjective speech intelligibility tuning, arbitrary host project reload, external sidechain DAW routing, Reason Computer Keys playback and VS2022 remain unverified. Factory phonemes are musical approximations, not language-accurate speech.

## 0.5 integration and performance

Final 0.5 gate: Debug **13/13 (38.22 s)** and Release **13/13 (5.68 s)**, exit 0 and no compiler warnings/errors. Both manifests report 0.5.0. Thirty-eight factory presets are exported. Actual FS and Klatt character panels, Klatt details, MEA Phonic details and TI speech view were rendered and visually inspected at 1100 × 950. Thirteen suites cover both VST3 products. The added processor regressions verify the unchanged five-step normalized legacy engine parameter, missing expansion/codec/engine defaults, all ten unified engine selections and state round trips, asynchronous GUI selection, all twelve added factory presets, and CC120 codec flushing against a fresh silent reference stream. The FS sine-table boundary that caused a Debug array assertion is covered explicitly. Assertions remain enabled and test runners report them to stderr instead of modal dialogs.

Local independent eight-voice benchmarks, measured as percentage of one core's real-time budget: FOF at 110/1200 Hz used 7.3/20.5% at 48 kHz, 14.3/40.4% at 96 kHz and 15.6/42.2% at 384 kHz. Its native synthesis rate is capped at 96 kHz with linear reconstruction above that. FS default settings measured about 26% at 48 kHz; its stress case (1200 Hz, narrow windows, eight voices) reached roughly 65% at 96/384 kHz. Reduce polyphony for heavy patches. These figures exclude GUI/DAW overhead and are machine-specific.

Klatt's independent comparison matched all 32,768 complete reference samples exactly. Eight-voice 64-sample callbacks measured about 19 microseconds median at 48 kHz. LPC-10 native frame work measured about 15 microseconds median / 26.4 maximum; its 64-sample 48 kHz wrapper callback measured about 34.5 microseconds maximum in the scratch benchmark. Its input conversion rejected a 7 kHz tone by about 122.5 dB relative to 1 kHz in that measurement.

The plugin reports zero host latency. LPC-10 is an intentional delayed effect (~166 ms), without automatic delay compensation; zero reported latency does not mean zero audible codec delay. Core-vector agreement does not prove historical voice/ROM or full-hardware equivalence. Real Reason sessions, listening quality and VS2022 remain unverified.

## 0.3 reference scope and delivery checks

The TI oracle is pinned to MAME commit `1ff183fcbd122ffb9ae5eb34c49c9c410ce83aa7`; fixture provenance is in `Tests/Data/PROVENANCE.txt`. Full-frame comparisons align the reference startup with the core's immediate software API. These cases validate synthesis behavior, not electrical timing, the toy CPU/ROM or an unsupported percentage of equivalence. The keyboard pitch extension and authored formant-to-LPC encoder are musical additions, not original toy firmware.

The effect retains component ID `ABCDEF019182FAEB566C616256634C62`; the new instrument uses `ABCDEF019182FAEB566C616256634C69`. Both manifests report 0.3.0 and their respective effect/instrument categories. The final TI instrument, TI effect and Phonic Keys views were rendered and visually inspected at the 1100 × 950 minimum size. All 18 factory presets were re-exported after the final build. The source and binary packages include the reference attribution and BSD notice.

## 0.4 regression and delivery scope

The same product component IDs are preserved; the 0.4 manifests report 0.4.0. All 26 factory presets were exported from the final Release processor. The actual TI text-speech panel, grouped Phonic Keys view and singing matrix were rendered and visually inspected at 1100 × 950. The fixed-capacity phrase command is tested through the real processor with callback allocation guards on all five speech modes, plus saved text/rate, legacy defaults, stop and no-autoplay restoration. The SP0256 eight-voice singing path also has guarded callback coverage.

The synthesis primitive comparisons do not certify original vocabulary/phone ROMs, complete SID/AY devices, intelligibility or percentage equivalence. SC filter comparisons use a relative/absolute tolerance of 1e-10; host musical control timing differs from the original digital controller. See RETRO-ENGINES.md and the fixture provenance files. CMUdict is bundled with its license and pinned revision. Offline word pronunciation is tested structurally, but listening refinement remains required.

Historical 0.1 final audit: clean configure and Debug/Release builds succeeded in `work/final-audit-build`. The audit found one additional Voice Synth pressure-routing issue; it was fixed and deterministic audio-comparison regressions were added. The independent rebuild of the corrected source passed **4/4 tests in Debug (5.47 s)** and **4/4 in Release (0.96 s)** with exit 0 and no compiler warnings. No confirmed findings remain open from the four audits. This does not replace the DAW/listening checks above.


## 0.2 regression coverage

Added: audio pitch measurement at octave-separated notes across all four engines and internal vocoder source routes; selected-bank-key mappings with played keys disabled; upper-register pitch, fixed carrier Hz, actual VST3 event-output bus and sample-offset preservation; GUI and host event merging through bypass; full-buffer deferral and overflow panic; MIDI file readback, final held-note duration, retakes; old/new routing-state recall and first-note preservation; real assignment control callbacks, edit-existing protection and linear fill range/order/clipping.

Actual Reason UI/audio sessions remain unverified. Reason behavior in README is based on the official Reason 14 manual; its documented lack of VST MIDI-output support is not claimed fixed by this plugin. The separate commercial GUI concept is a mockup; the screenshots in this folder are the actual implemented JUCE editor.

Final 0.2 build: Debug **4/4 tests (9.70 s)** and Release **4/4 (1.29 s)**, exit 0, no compiler warnings. All four implemented editor views were re-rendered, and 14 factory presets were re-exported. The audio tests use a heap-owned processor because the fixed recorder/bank storage is intentionally too large for nested default-Windows-stack test fixtures.
